SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC [dbo].[SP_InsertManagement] (

  @managementName varchar(60),
  @address varchar(80),
  @contact NUMERIC
) AS
BEGIN
    INSERT INTO Management (managementName, address, contact)
    VALUES (@managementName, @address, @contact);

END
GO
