--dbo.OrderDetails

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[OrderDetails] AS Select  c.studentID, c.studentName, d.orderID, d.orderDate, e.packageID, e.packageName,e.packageCost, f.deliveryDate,f.deliveryStatus, g.employeeName, g.employeeMobileNO, h.managerID, h.managerName from 
    dbo.Student c
   LEFT JOIN dbo.[order] d on c.studentID = d.studentID
   LEFT JOIN dbo.[Catering package] e on d.packageID = e.packageID
 LEFT JOIN dbo.Delivery f on d.orderID = f.orderID
   LEFT JOIN dbo.Employee g on f.employeeID = g.employeeID
   LEFT JOIN dbo.[Hostel Manager] h on f.managerID = h.managerID;
GO

--dbo.OrderDetails_Delivered

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[OrderDetails_Delivered] AS Select  c.studentID, c.studentName, d.orderID, d.orderDate, e.packageID, e.packageName,e.packageCost, f.deliveryDate,f.deliveryStatus, g.employeeName, g.employeeMobileNO, h.managerID, h.managerName from 
    dbo.Student c
   LEFT JOIN dbo.[order] d on c.studentID = d.studentID
   LEFT JOIN dbo.[Catering package] e on d.packageID = e.packageID
 LEFT JOIN dbo.Delivery f on d.orderID = f.orderID
   LEFT JOIN dbo.Employee g on f.employeeID = g.employeeID
   LEFT JOIN dbo.[Hostel Manager] h on f.managerID = h.managerID where f.deliveryStatus = 'Deliverd';
GO

--dbo.OderDetails_Not_Delivered

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[OrderDetails_Not_Delivered] AS Select  c.studentID, c.studentName, d.orderID, d.orderDate, e.packageID, e.packageName,e.packageCost, f.deliveryDate,f.deliveryStatus, g.employeeName, g.employeeMobileNO, h.managerID, h.managerName from 
    dbo.Student c
   LEFT JOIN dbo.[order] d on c.studentID = d.studentID
   LEFT JOIN dbo.[Catering package] e on d.packageID = e.packageID
 LEFT JOIN dbo.Delivery f on d.orderID = f.orderID
   LEFT JOIN dbo.Employee g on f.employeeID = g.employeeID
   LEFT JOIN dbo.[Hostel Manager] h on f.managerID = h.managerID where f.deliveryStatus = 'Not-Delivered';
GO

--dbo.StudentDetails

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[StudentDetails] AS Select d.roomID, c.studentID, c.studentName, h.managementName, g.managerName, f.hostelName from 
    dbo.Student c
   LEFT JOIN dbo.[Room Date] d on c.studentID = d.studentID
   LEFT JOIN dbo.Room e on d.roomID = e.roomID
 LEFT JOIN dbo.Hostel f on e.hostelID = f.hostelID
   LEFT JOIN dbo.[Hostel Manager] g on f.managerID = g.managerID
   LEFT JOIN dbo.Management h on g.managementID = h.managementID;
GO

--dbo.StudentFeedbackToManagementTable

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[StudentFeedbackToManagementTable] AS 
   Select d.roomID, c.studentID, c.studentName,  b.managementName, a.feedback,a.[Date] from 
   dbo.feedback a
   LEFT JOIN dbo.Management b on a.managementID = b.managementID 
   LEFT JOIN dbo.Student c on  a.studentID = c.studentID 
   LEFT JOIN dbo.[Room Date] d on c.studentID = d.studentID
GO


--Trigger
--dbo.Student
--Update_studentMobileNo

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [dbo].[Update_studentMobileNo] ON [dbo].[Student]
After UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @ID int
    DECLARE @action varchar(100), @NewContactNo bigint, @OldContactNo bigint

    Select @ID = inserted.studentID
    from inserted

    Select *
      into #TempTable
      from inserted

    Select Top 1 @NewContactNo = studentMobileNO from #TempTable

    Select @OldContactNo = studentMobileNO from deleted where studentID = @ID

    IF UPDATE(studentMobileNO)
        SET @action = 'Updated Contact Number from ' + Cast(@OldContactNo as varchar(15)) + ' to ' +  Cast(@NewContactNo as varchar(15)) + 
        ' for the user with account ID ' + Cast(@ID as varchar(15))
    
    INSERT INTO usr_account_audit_tbl
    VALUES(@ID, @action)

END
GO
ALTER TABLE [dbo].[Student] ENABLE TRIGGER [Update_studentMobileNo]
GO


