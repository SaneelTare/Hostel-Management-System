SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROC [dbo].[SP_Insertemployee] (
  @employeeName nvarchar(60),
  @employeeEmail varchar(100),
  @employeeAddress varchar(100),
   @employeeMobileNO char(10)
) AS
BEGIN
    INSERT INTO Employee (employeeName, employeeEmail, employeeAddress,employeeMobileNO )
    VALUES (@employeeName, @employeeEmail, @employeeAddress,@employeeMobileNO);

END
GO
