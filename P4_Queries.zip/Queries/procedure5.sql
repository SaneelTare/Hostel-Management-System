SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  CREATE PROC [dbo].[sp.Get_Total_count_of_Orders_Not_Delivered] (@deliveryStatus VARCHAR(45))
    AS
BEGIN
  select distinct count(*) as TotalCount from student a, [order] b, employee c, delivery d where a.studentID = b.studentID 
  and d.employeeID =c.employeeID and b.orderID = d.orderID and d.deliveryStatus = @deliveryStatus

END
GO
